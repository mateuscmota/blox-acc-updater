using System;
using System.Diagnostics;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;

namespace RBX_Alt_Manager.Classes
{
    /// <summary>
    /// Integração com RoSolve API para resolver FunCaptcha
    /// Documentação: https://rosolve.pro/docs/rest-api
    /// </summary>
    public class RoSolveSolver
    {
        // API Key do RoSolve - HARDCODED
        private const string API_KEY = "98cc5bf4fd15915030e8fd96a88ab25d1d213a69ebea666d5e046cb73714c1a2";
        private const string API_BASE_URL = "https://rosolve.pro";
        
        // Proxy padrão - REQUIRED pela API
        private const string DEFAULT_PROXY = "socks5://7976f655026bca35799e__cr.br:bfb4d44b738bce42@gw.dataimpulse.com:824";
        
        // Configurações padrão do Roblox
        private const string ROBLOX_PUBLIC_KEY = "A2A14B1D-1AF3-C791-9BBC-EE33CC7A0A6F";
        private const string ROBLOX_SURL = "https://roblox-api.arkoselabs.com";
        private const string ROBLOX_SITE = "https://www.roblox.com";

        private readonly HttpClient _httpClient;

        public RoSolveSolver()
        {
            _httpClient = new HttpClient();
            _httpClient.Timeout = TimeSpan.FromSeconds(180);
        }

        /// <summary>
        /// Verifica o saldo da conta RoSolve
        /// Endpoint: GET /getSolves?key=API_KEY
        /// </summary>
        public async Task<(bool success, int solves, string error)> GetBalanceAsync()
        {
            try
            {
                var response = await _httpClient.GetAsync($"{API_BASE_URL}/getSolves?key={API_KEY}");
                var content = await response.Content.ReadAsStringAsync();
                
                Debug.WriteLine($"[ROSOLVE] Balance Response: {content}");
                AccountManager.AddLog($"[DEBUG] Balance raw: {content.Substring(0, Math.Min(100, content.Length))}");
                
                if (content.TrimStart().StartsWith("<"))
                {
                    // HTML response - provavelmente erro
                    return (false, 0, "API retornou HTML ao invés de JSON");
                }
                
                var json = JObject.Parse(content);
                
                if (json["error"] != null)
                {
                    return (false, 0, json["error"].ToString());
                }
                
                var solves = json["solves"]?.Value<int>() ?? 0;
                return (true, solves, null);
            }
            catch (Exception ex)
            {
                return (false, 0, ex.Message);
            }
        }

        /// <summary>
        /// Cria uma tarefa de resolução de FunCaptcha
        /// Endpoint: POST /createTask
        /// </summary>
        public async Task<(bool success, string taskId, string error)> CreateTaskAsync(
            string blob = null,
            string proxy = null,
            string cookie = null)
        {
            try
            {
                // Construir payload conforme documentação oficial
                var requestBody = new JObject
                {
                    ["key"] = API_KEY,
                    ["challengeInfo"] = new JObject
                    {
                        ["publicKey"] = ROBLOX_PUBLIC_KEY,
                        ["site"] = ROBLOX_SITE,
                        ["surl"] = ROBLOX_SURL,
                        ["capiMode"] = "lightbox",  // Corrigido: capiMode não mode
                        ["styleTheme"] = "default",
                        ["locationHref"] = "https://www.roblox.com/login",
                        ["documentReferrer"] = "https://www.roblox.com/",
                        ["documentTitle"] = "Login - Roblox",
                        ["ancestorOrigins"] = new JArray { "https://www.roblox.com" },
                        ["treeIndex"] = new JArray { 0 },
                        ["treeStructure"] = "[[]]",
                        ["languageEnabled"] = true,
                        ["jsfEnabled"] = true,  // Corrigido: jsfEnabled não jsEnabled
                        ["appMode"] = false,
                        ["solvePOW"] = true,
                        ["analyticsPOW"] = true,
                        ["cookieTimestamp"] = true
                    },
                    ["browserInfo"] = new JObject
                    {
                        ["Accept-Language"] = "en-US,en;q=0.9",
                        ["Mobile"] = false,  // Corrigido: Mobile (capitalizado)
                        ["Sec-Ch-Ua"] = "\"Google Chrome\";v=\"131\", \"Chromium\";v=\"131\", \"Not_A Brand\";v=\"24\"",
                        ["User-Agent"] = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
                        ["dataBrands"] = "Not_A Brand,Google Chrome,Chromium",
                        ["languages"] = "en-US,en"
                    }
                };

                // Adicionar blob se fornecido
                if (!string.IsNullOrEmpty(blob))
                {
                    requestBody["challengeInfo"]["extraData"] = new JObject
                    {
                        ["blob"] = blob
                    };
                }

                // Adicionar proxy (REQUIRED pelo API)
                string proxyToUse = !string.IsNullOrEmpty(proxy) ? proxy : DEFAULT_PROXY;
                requestBody["proxy"] = proxyToUse;
                AccountManager.AddLog($"🌐 Usando proxy: {proxyToUse.Substring(0, Math.Min(30, proxyToUse.Length))}...");

                // Adicionar cookie se fornecido
                if (!string.IsNullOrEmpty(cookie))
                {
                    requestBody["browserInfo"]["Cookie"] = cookie;  // Corrigido: Cookie (capitalizado)
                }

                var jsonContent = new StringContent(
                    requestBody.ToString(),
                    Encoding.UTF8,
                    "application/json"
                );

                AccountManager.AddLog("📤 RoSolve: Criando tarefa...");
                Debug.WriteLine($"[ROSOLVE] CreateTask Request: {requestBody}");
                
                var response = await _httpClient.PostAsync($"{API_BASE_URL}/createTask", jsonContent);
                var content = await response.Content.ReadAsStringAsync();

                Debug.WriteLine($"[ROSOLVE] CreateTask Response: {content}");
                
                if (content.TrimStart().StartsWith("<"))
                {
                    AccountManager.AddLog($"❌ RoSolve: API retornou HTML");
                    return (false, null, "API retornou HTML ao invés de JSON");
                }

                var json = JObject.Parse(content);

                if (json["taskId"] != null)
                {
                    var taskId = json["taskId"].ToString();
                    AccountManager.AddLog($"✅ RoSolve: Tarefa criada: {taskId.Substring(0, Math.Min(8, taskId.Length))}...");
                    return (true, taskId, null);
                }
                else
                {
                    var error = json["error"]?.ToString() ?? content;
                    AccountManager.AddLog($"❌ RoSolve: {error}");
                    return (false, null, error);
                }
            }
            catch (Exception ex)
            {
                AccountManager.AddLog($"❌ RoSolve Exception: {ex.Message}");
                return (false, null, ex.Message);
            }
        }

        /// <summary>
        /// Obtém o resultado de uma tarefa
        /// Endpoint: POST /taskResult
        /// </summary>
        public async Task<(bool success, string solution, string status, string error)> GetResultAsync(string taskId)
        {
            try
            {
                var requestBody = new JObject
                {
                    ["key"] = API_KEY,
                    ["taskId"] = taskId
                };

                var jsonContent = new StringContent(
                    requestBody.ToString(),
                    Encoding.UTF8,
                    "application/json"
                );

                var response = await _httpClient.PostAsync($"{API_BASE_URL}/taskResult", jsonContent);  // Corrigido: taskResult não getResult
                var content = await response.Content.ReadAsStringAsync();

                Debug.WriteLine($"[ROSOLVE] TaskResult Response: {content}");

                if (content.TrimStart().StartsWith("<"))
                {
                    return (false, null, "error", "API retornou HTML");
                }

                var json = JObject.Parse(content);
                var status = json["status"]?.ToString() ?? "unknown";

                if (status == "completed")
                {
                    // Estrutura correta: result.solution
                    var solution = json["result"]?["solution"]?.ToString();
                    var gameInfo = json["result"]?["gameInfo"];
                    var variant = gameInfo?["variant"]?.ToString() ?? "unknown";
                    var solveTime = gameInfo?["solveTime"]?.Value<double>() ?? 0;
                    
                    AccountManager.AddLog($"✅ RoSolve: Resolvido! ({variant}, {solveTime:F2}s)");
                    return (true, solution, status, null);
                }
                else if (status == "failed")
                {
                    var error = json["result"]?["error"]?.ToString() ?? "Falha desconhecida";
                    return (false, null, status, error);
                }
                else
                {
                    // Ainda processando (pending/processing)
                    return (false, null, status, null);
                }
            }
            catch (Exception ex)
            {
                return (false, null, "error", ex.Message);
            }
        }

        /// <summary>
        /// Resolve FunCaptcha usando RoSolve (método principal)
        /// </summary>
        public async Task<(bool success, string token, string error)> SolveFunCaptchaAsync(
            string blob = null,
            string proxy = null,
            string cookie = null,
            int maxWaitSeconds = 120,
            int pollIntervalMs = 2000)
        {
            // 1. Verificar saldo primeiro
            AccountManager.AddLog("🔍 RoSolve: Verificando saldo...");
            var (balanceOk, solves, balanceError) = await GetBalanceAsync();
            
            if (!balanceOk)
            {
                AccountManager.AddLog($"❌ RoSolve: Erro ao verificar saldo: {balanceError}");
                return (false, null, $"Erro ao verificar saldo: {balanceError}");
            }

            AccountManager.AddLog($"💰 RoSolve: Saldo = {solves} solves");

            if (solves <= 0)
            {
                AccountManager.AddLog("❌ RoSolve: Saldo insuficiente!");
                return (false, null, "Saldo insuficiente no RoSolve");
            }

            // 2. Criar tarefa
            var (createOk, taskId, createError) = await CreateTaskAsync(blob, proxy, cookie);
            
            if (!createOk)
            {
                return (false, null, createError);
            }

            // 3. Aguardar resultado
            var stopwatch = Stopwatch.StartNew();
            int attempts = 0;

            while (stopwatch.Elapsed.TotalSeconds < maxWaitSeconds)
            {
                attempts++;
                await Task.Delay(pollIntervalMs);

                var (resultOk, solution, status, resultError) = await GetResultAsync(taskId);

                if (resultOk && !string.IsNullOrEmpty(solution))
                {
                    stopwatch.Stop();
                    AccountManager.AddLog($"🎉 RoSolve: Token obtido em {stopwatch.Elapsed.TotalSeconds:F1}s");
                    return (true, solution, null);
                }
                else if (status == "failed")
                {
                    stopwatch.Stop();
                    AccountManager.AddLog($"❌ RoSolve: Falha - {resultError}");
                    return (false, null, resultError);
                }
                else
                {
                    // Ainda processando - mostrar progresso a cada 5 tentativas
                    if (attempts % 5 == 0)
                    {
                        AccountManager.AddLog($"⏳ RoSolve: Aguardando... ({stopwatch.Elapsed.TotalSeconds:F0}s)");
                    }
                }
            }

            // Timeout
            stopwatch.Stop();
            AccountManager.AddLog($"❌ RoSolve: Timeout após {maxWaitSeconds}s");
            return (false, null, $"Timeout após {maxWaitSeconds} segundos");
        }

        /// <summary>
        /// Extrai o blob do header rblx-challenge-metadata (base64)
        /// </summary>
        public static string ExtractBlobFromMetadata(string base64Metadata)
        {
            try
            {
                string decoded = Encoding.UTF8.GetString(Convert.FromBase64String(base64Metadata));
                var json = JObject.Parse(decoded);
                return json["dataExchangeBlob"]?.ToString();
            }
            catch
            {
                return null;
            }
        }
    }
}
