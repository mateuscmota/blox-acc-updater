﻿using System.Collections.Generic;

namespace RBX_Alt_Manager
{
    public class GameInstancesCollection
    {
        public long PlaceId;
        public bool ShowShutdownAllButton;
        public List<GameInstance> Collection;
        public int TotalCollectionSize;
    }
}