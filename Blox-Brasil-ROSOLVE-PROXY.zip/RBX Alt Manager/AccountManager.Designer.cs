﻿using RBX_Alt_Manager.Classes;

namespace RBX_Alt_Manager
{
    partial class AccountManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AccountManager));
            this.LabelJobID = new System.Windows.Forms.Label();
            this.AddAccountsStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.manualToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bulkUserPassToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.byCookieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.customURLJSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Remover = new System.Windows.Forms.Button();
            this.JoinServer = new System.Windows.Forms.Button();
            this.SolveCaptchaButton = new System.Windows.Forms.Button();
            this.SetDescription = new System.Windows.Forms.Button();
            this.Follow = new System.Windows.Forms.Button();
            this.LabelUserID = new System.Windows.Forms.Label();
            this.AccountsStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.addAccountsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.removeAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyUsernameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyPasswordToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyUserPassComboToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyProfileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyUserIdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sortAlphabeticallyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quickLogInToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.moveGroupUpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toggleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.moveToToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyGroupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.infoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groupsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.infoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.viewFieldsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ShowDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.getAuthenticationTicketToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copySecurityTokenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyRbxplayerLinkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyAppLinkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.BrowserButton = new System.Windows.Forms.Button();
            this.DebugLogTextBox = new System.Windows.Forms.TextBox();
            this.AddFriendLabel = new System.Windows.Forms.Label();
            this.AddFriendTextBox = new System.Windows.Forms.TextBox();
            this.AddFriendButton = new System.Windows.Forms.Button();
            this.LabelPlaceID = new System.Windows.Forms.Label();
            this.PlaceTimer = new System.Windows.Forms.Timer(this.components);
            this.OpenBrowserStrip = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.customURLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.URLJSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.joinGroupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveTooltip = new System.Windows.Forms.ToolTip(this.components);
            this.DefaultEncryptionButton = new System.Windows.Forms.Button();
            this.PasswordEncryptionButton = new System.Windows.Forms.Button();
            this.JobID = new RBX_Alt_Manager.Classes.BorderedTextBox();
            this.ClearJobIDButton = new System.Windows.Forms.Button();
            this.AccountsView = new BrightIdeasSoftware.ObjectListView();
            this.Username = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.Description = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.Group = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.LastUsedColumn = ((BrightIdeasSoftware.OLVColumn)(new BrightIdeasSoftware.OLVColumn()));
            this.EditTheme = new System.Windows.Forms.Button();
            this.ConfigButton = new System.Windows.Forms.Button();
            this.HistoryIcon = new System.Windows.Forms.PictureBox();
            this.PasswordPanel = new System.Windows.Forms.Panel();
            this.PasswordLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.UnlockButton = new System.Windows.Forms.Button();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.AccessLabel = new System.Windows.Forms.Label();
            this.PasswordRequiredLabel = new System.Windows.Forms.Label();
            this.PasswordSelectionPanel = new System.Windows.Forms.TableLayoutPanel();
            this.SetPasswordButton = new System.Windows.Forms.Button();
            this.PasswordSelectionTB = new System.Windows.Forms.TextBox();
            this.Password2Label = new System.Windows.Forms.Label();
            this.EncryptionSelectionPanel = new System.Windows.Forms.TableLayoutPanel();
            this.EncSelectionLabel = new System.Windows.Forms.Label();
            this.DownloadProgressBar = new System.Windows.Forms.ProgressBar();
            this.PresenceUpdateTimer = new System.Windows.Forms.Timer(this.components);
            this.DLChromiumLabel = new System.Windows.Forms.Label();
            this.SearchAccountsTextBox = new System.Windows.Forms.TextBox();
            this.ClearSearchButton = new System.Windows.Forms.Button();
            this.SearchAccountsLabel = new System.Windows.Forms.Label();
            this.PrivateServersPanel = new System.Windows.Forms.Panel();
            this.AddServerButton = new System.Windows.Forms.Button();
            this.NewServerLinkTextBox = new System.Windows.Forms.TextBox();
            this.NewServerLinkLabel = new System.Windows.Forms.Label();
            this.NewServerNameTextBox = new System.Windows.Forms.TextBox();
            this.NewServerNameLabel = new System.Windows.Forms.Label();
            this.PrivateServersListPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.PrivateServersLabel = new System.Windows.Forms.Label();
            this.AntiCaptchaComboBox = new System.Windows.Forms.ComboBox();
            this.AntiCaptchaLabel = new System.Windows.Forms.Label();
            this.AddUserPassButton = new System.Windows.Forms.Button();
            this.AddCookieButton = new System.Windows.Forms.Button();
            this.OpenBrowser = new RBX_Alt_Manager.Classes.MenuButton();
            this.UserID = new RBX_Alt_Manager.Classes.BorderedTextBox();
            this.DescriptionBox = new RBX_Alt_Manager.Classes.BorderedRichTextBox();
            this.PlaceID = new RBX_Alt_Manager.Classes.BorderedTextBox();
            this.AddAccountsStrip.SuspendLayout();
            this.AccountsStrip.SuspendLayout();
            this.OpenBrowserStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AccountsView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HistoryIcon)).BeginInit();
            this.PasswordPanel.SuspendLayout();
            this.PasswordLayoutPanel.SuspendLayout();
            this.PasswordSelectionPanel.SuspendLayout();
            this.EncryptionSelectionPanel.SuspendLayout();
            this.PrivateServersPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // LabelJobID
            // 
            this.LabelJobID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LabelJobID.AutoSize = true;
            this.LabelJobID.Location = new System.Drawing.Point(759, 62);
            this.LabelJobID.Name = "LabelJobID";
            this.LabelJobID.Size = new System.Drawing.Size(77, 13);
            this.LabelJobID.TabIndex = 1000;
            this.LabelJobID.Text = "Server Privado";
            this.SaveTooltip.SetToolTip(this.LabelJobID, "Job ID is a unique ID assigned to every roblox server.");
            this.LabelJobID.Click += new System.EventHandler(this.LabelJobID_Click);
            // 
            // AddAccountsStrip
            // 
            this.AddAccountsStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.manualToolStripMenuItem,
            this.bulkUserPassToolStripMenuItem,
            this.byCookieToolStripMenuItem,
            this.customURLJSToolStripMenuItem});
            this.AddAccountsStrip.Name = "AddAccountsStrip";
            this.AddAccountsStrip.Size = new System.Drawing.Size(173, 92);
            // 
            // manualToolStripMenuItem
            // 
            this.manualToolStripMenuItem.Name = "manualToolStripMenuItem";
            this.manualToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.manualToolStripMenuItem.Text = "Manual Login";
            this.manualToolStripMenuItem.Click += new System.EventHandler(this.manualToolStripMenuItem_Click);
            // 
            // bulkUserPassToolStripMenuItem
            // 
            this.bulkUserPassToolStripMenuItem.Name = "bulkUserPassToolStripMenuItem";
            this.bulkUserPassToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.bulkUserPassToolStripMenuItem.Text = "User:Pass";
            this.bulkUserPassToolStripMenuItem.Click += new System.EventHandler(this.bulkUserPassToolStripMenuItem_Click);
            // 
            // byCookieToolStripMenuItem
            // 
            this.byCookieToolStripMenuItem.Name = "byCookieToolStripMenuItem";
            this.byCookieToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.byCookieToolStripMenuItem.Text = "Cookie(s)";
            this.byCookieToolStripMenuItem.Click += new System.EventHandler(this.byCookieToolStripMenuItem_Click);
            // 
            // customURLJSToolStripMenuItem
            // 
            this.customURLJSToolStripMenuItem.Name = "customURLJSToolStripMenuItem";
            this.customURLJSToolStripMenuItem.Size = new System.Drawing.Size(172, 22);
            this.customURLJSToolStripMenuItem.Text = "Custom (URL + JS)";
            this.customURLJSToolStripMenuItem.Click += new System.EventHandler(this.customURLJSToolStripMenuItem_Click);
            // 
            // Remover
            // 
            this.Remover.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Remover.Location = new System.Drawing.Point(667, 440);
            this.Remover.Name = "Remover";
            this.Remover.Size = new System.Drawing.Size(86, 23);
            this.Remover.TabIndex = 15;
            this.Remover.Text = "Remove";
            this.Remover.UseVisualStyleBackColor = true;
            this.Remover.Click += new System.EventHandler(this.Remove_Click);
            // 
            // JoinServer
            // 
            this.JoinServer.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.JoinServer.Location = new System.Drawing.Point(762, 103);
            this.JoinServer.Name = "JoinServer";
            this.JoinServer.Size = new System.Drawing.Size(170, 23);
            this.JoinServer.TabIndex = 4;
            this.JoinServer.Text = "Entrar no Jogo";
            this.JoinServer.UseVisualStyleBackColor = true;
            this.JoinServer.Click += new System.EventHandler(this.JoinServer_Click);
            // 
            // SolveCaptchaButton
            // 
            this.SolveCaptchaButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SolveCaptchaButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.SolveCaptchaButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.SolveCaptchaButton.ForeColor = System.Drawing.Color.White;
            this.SolveCaptchaButton.Location = new System.Drawing.Point(762, 128);
            this.SolveCaptchaButton.Name = "SolveCaptchaButton";
            this.SolveCaptchaButton.Size = new System.Drawing.Size(170, 23);
            this.SolveCaptchaButton.TabIndex = 1400;
            this.SolveCaptchaButton.Text = "🔓 RESOLVER CAPTCHA";
            this.SolveCaptchaButton.UseVisualStyleBackColor = false;
            this.SolveCaptchaButton.Click += new System.EventHandler(this.SolveCaptchaButton_Click);
            // 
            // SetDescription
            // 
            this.SetDescription.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.SetDescription.Location = new System.Drawing.Point(762, 239);
            this.SetDescription.Name = "SetDescription";
            this.SetDescription.Size = new System.Drawing.Size(170, 23);
            this.SetDescription.TabIndex = 12;
            this.SetDescription.Text = "Alterar Descrição";
            this.SetDescription.UseVisualStyleBackColor = true;
            this.SetDescription.Click += new System.EventHandler(this.SetDescription_Click);
            // 
            // Follow
            // 
            this.Follow.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.Follow.Location = new System.Drawing.Point(867, 170);
            this.Follow.Name = "Follow";
            this.Follow.Size = new System.Drawing.Size(65, 23);
            this.Follow.TabIndex = 8;
            this.Follow.Text = "Seguir";
            this.SaveTooltip.SetToolTip(this.Follow, "Follows a user into their game.");
            this.Follow.UseVisualStyleBackColor = true;
            this.Follow.Click += new System.EventHandler(this.Follow_Click);
            // 
            // LabelUserID
            // 
            this.LabelUserID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LabelUserID.AutoSize = true;
            this.LabelUserID.Location = new System.Drawing.Point(759, 156);
            this.LabelUserID.Name = "LabelUserID";
            this.LabelUserID.Size = new System.Drawing.Size(92, 13);
            this.LabelUserID.TabIndex = 1000;
            this.LabelUserID.Text = "Nome para Seguir";
            this.LabelUserID.Click += new System.EventHandler(this.LabelUserID_Click);
            // 
            // AccountsStrip
            // 
            this.AccountsStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addAccountsToolStripMenuItem,
            this.removeAccountToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.sortAlphabeticallyToolStripMenuItem,
            this.quickLogInToolStripMenuItem,
            this.moveGroupUpToolStripMenuItem,
            this.infoToolStripMenuItem,
            this.viewFieldsToolStripMenuItem,
            this.ShowDetailsToolStripMenuItem,
            this.getAuthenticationTicketToolStripMenuItem,
            this.copySecurityTokenToolStripMenuItem,
            this.copyRbxplayerLinkToolStripMenuItem,
            this.copyAppLinkToolStripMenuItem});
            this.AccountsStrip.Name = "contextMenuStrip1";
            this.AccountsStrip.Size = new System.Drawing.Size(210, 290);
            // 
            // addAccountsToolStripMenuItem
            // 
            this.addAccountsToolStripMenuItem.Name = "addAccountsToolStripMenuItem";
            this.addAccountsToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.addAccountsToolStripMenuItem.Text = "Add Account";
            this.addAccountsToolStripMenuItem.Click += new System.EventHandler(this.addAccountsToolStripMenuItem_Click);
            // 
            // removeAccountToolStripMenuItem
            // 
            this.removeAccountToolStripMenuItem.Name = "removeAccountToolStripMenuItem";
            this.removeAccountToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.removeAccountToolStripMenuItem.Text = "Remove Account";
            this.removeAccountToolStripMenuItem.Click += new System.EventHandler(this.removeAccountToolStripMenuItem_Click);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyUsernameToolStripMenuItem,
            this.copyPasswordToolStripMenuItem,
            this.copyUserPassComboToolStripMenuItem,
            this.copyProfileToolStripMenuItem,
            this.copyUserIdToolStripMenuItem});
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.copyToolStripMenuItem.Text = "Copy";
            // 
            // copyUsernameToolStripMenuItem
            // 
            this.copyUsernameToolStripMenuItem.Name = "copyUsernameToolStripMenuItem";
            this.copyUsernameToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.copyUsernameToolStripMenuItem.Text = "Copy Username";
            this.copyUsernameToolStripMenuItem.Click += new System.EventHandler(this.copyUsernameToolStripMenuItem_Click);
            // 
            // copyPasswordToolStripMenuItem
            // 
            this.copyPasswordToolStripMenuItem.Name = "copyPasswordToolStripMenuItem";
            this.copyPasswordToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.copyPasswordToolStripMenuItem.Text = "Copy Password";
            this.copyPasswordToolStripMenuItem.Click += new System.EventHandler(this.copyPasswordToolStripMenuItem_Click);
            // 
            // copyUserPassComboToolStripMenuItem
            // 
            this.copyUserPassComboToolStripMenuItem.Name = "copyUserPassComboToolStripMenuItem";
            this.copyUserPassComboToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.copyUserPassComboToolStripMenuItem.Text = "Copy User Pass Combo";
            this.copyUserPassComboToolStripMenuItem.Click += new System.EventHandler(this.copyUserPassComboToolStripMenuItem_Click);
            // 
            // copyProfileToolStripMenuItem
            // 
            this.copyProfileToolStripMenuItem.Name = "copyProfileToolStripMenuItem";
            this.copyProfileToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.copyProfileToolStripMenuItem.Text = "Copy Profile";
            this.copyProfileToolStripMenuItem.Click += new System.EventHandler(this.copyProfileToolStripMenuItem_Click);
            // 
            // copyUserIdToolStripMenuItem
            // 
            this.copyUserIdToolStripMenuItem.Name = "copyUserIdToolStripMenuItem";
            this.copyUserIdToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.copyUserIdToolStripMenuItem.Text = "Copy UserId";
            this.copyUserIdToolStripMenuItem.Click += new System.EventHandler(this.copyUserIdToolStripMenuItem_Click);
            // 
            // sortAlphabeticallyToolStripMenuItem
            // 
            this.sortAlphabeticallyToolStripMenuItem.Name = "sortAlphabeticallyToolStripMenuItem";
            this.sortAlphabeticallyToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.sortAlphabeticallyToolStripMenuItem.Text = "Sort Alphabetically";
            this.sortAlphabeticallyToolStripMenuItem.Click += new System.EventHandler(this.sortAlphabeticallyToolStripMenuItem_Click);
            // 
            // quickLogInToolStripMenuItem
            // 
            this.quickLogInToolStripMenuItem.Name = "quickLogInToolStripMenuItem";
            this.quickLogInToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.quickLogInToolStripMenuItem.Text = "Quick Log In";
            this.quickLogInToolStripMenuItem.Click += new System.EventHandler(this.quickLogInToolStripMenuItem_Click);
            // 
            // moveGroupUpToolStripMenuItem
            // 
            this.moveGroupUpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toggleToolStripMenuItem,
            this.moveToToolStripMenuItem,
            this.copyGroupToolStripMenuItem});
            this.moveGroupUpToolStripMenuItem.Name = "moveGroupUpToolStripMenuItem";
            this.moveGroupUpToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.moveGroupUpToolStripMenuItem.Text = "Groups";
            // 
            // toggleToolStripMenuItem
            // 
            this.toggleToolStripMenuItem.Name = "toggleToolStripMenuItem";
            this.toggleToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.toggleToolStripMenuItem.Text = "Toggle";
            this.toggleToolStripMenuItem.Click += new System.EventHandler(this.toggleToolStripMenuItem_Click);
            // 
            // moveToToolStripMenuItem
            // 
            this.moveToToolStripMenuItem.Name = "moveToToolStripMenuItem";
            this.moveToToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.moveToToolStripMenuItem.Text = "Move Account To";
            this.moveToToolStripMenuItem.Click += new System.EventHandler(this.moveToToolStripMenuItem_Click);
            // 
            // copyGroupToolStripMenuItem
            // 
            this.copyGroupToolStripMenuItem.Name = "copyGroupToolStripMenuItem";
            this.copyGroupToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.copyGroupToolStripMenuItem.Text = "Copy Group";
            this.copyGroupToolStripMenuItem.Click += new System.EventHandler(this.copyGroupToolStripMenuItem_Click);
            // 
            // infoToolStripMenuItem
            // 
            this.infoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.groupsToolStripMenuItem,
            this.infoToolStripMenuItem1});
            this.infoToolStripMenuItem.Name = "infoToolStripMenuItem";
            this.infoToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.infoToolStripMenuItem.Text = "Help";
            // 
            // groupsToolStripMenuItem
            // 
            this.groupsToolStripMenuItem.Name = "groupsToolStripMenuItem";
            this.groupsToolStripMenuItem.Size = new System.Drawing.Size(112, 22);
            this.groupsToolStripMenuItem.Text = "Groups";
            this.groupsToolStripMenuItem.Click += new System.EventHandler(this.groupsToolStripMenuItem_Click);
            // 
            // infoToolStripMenuItem1
            // 
            this.infoToolStripMenuItem1.Name = "infoToolStripMenuItem1";
            this.infoToolStripMenuItem1.Size = new System.Drawing.Size(112, 22);
            this.infoToolStripMenuItem1.Text = "Info";
            this.infoToolStripMenuItem1.Click += new System.EventHandler(this.infoToolStripMenuItem1_Click);
            // 
            // viewFieldsToolStripMenuItem
            // 
            this.viewFieldsToolStripMenuItem.Name = "viewFieldsToolStripMenuItem";
            this.viewFieldsToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.viewFieldsToolStripMenuItem.Text = "View Fields";
            this.viewFieldsToolStripMenuItem.Click += new System.EventHandler(this.viewFieldsToolStripMenuItem_Click);
            // 
            // ShowDetailsToolStripMenuItem
            // 
            this.ShowDetailsToolStripMenuItem.Name = "ShowDetailsToolStripMenuItem";
            this.ShowDetailsToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.ShowDetailsToolStripMenuItem.Text = "Dump Details";
            this.ShowDetailsToolStripMenuItem.Click += new System.EventHandler(this.ShowDetailsToolStripMenuItem_Click);
            // 
            // getAuthenticationTicketToolStripMenuItem
            // 
            this.getAuthenticationTicketToolStripMenuItem.Name = "getAuthenticationTicketToolStripMenuItem";
            this.getAuthenticationTicketToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.getAuthenticationTicketToolStripMenuItem.Text = "Get Authentication Ticket";
            this.getAuthenticationTicketToolStripMenuItem.Click += new System.EventHandler(this.getAuthenticationTicketToolStripMenuItem_Click);
            // 
            // copySecurityTokenToolStripMenuItem
            // 
            this.copySecurityTokenToolStripMenuItem.Name = "copySecurityTokenToolStripMenuItem";
            this.copySecurityTokenToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.copySecurityTokenToolStripMenuItem.Text = "Copy Cookie";
            this.copySecurityTokenToolStripMenuItem.Click += new System.EventHandler(this.copySecurityTokenToolStripMenuItem_Click);
            // 
            // copyRbxplayerLinkToolStripMenuItem
            // 
            this.copyRbxplayerLinkToolStripMenuItem.Name = "copyRbxplayerLinkToolStripMenuItem";
            this.copyRbxplayerLinkToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.copyRbxplayerLinkToolStripMenuItem.Text = "Copy rbx-player Link";
            this.copyRbxplayerLinkToolStripMenuItem.Click += new System.EventHandler(this.copyRbxplayerLinkToolStripMenuItem_Click);
            // 
            // copyAppLinkToolStripMenuItem
            // 
            this.copyAppLinkToolStripMenuItem.Name = "copyAppLinkToolStripMenuItem";
            this.copyAppLinkToolStripMenuItem.Size = new System.Drawing.Size(209, 22);
            this.copyAppLinkToolStripMenuItem.Text = "Copy App Link";
            this.copyAppLinkToolStripMenuItem.Click += new System.EventHandler(this.copyAppLinkToolStripMenuItem_Click);
            // 
            // BrowserButton
            // 
            this.BrowserButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BrowserButton.Location = new System.Drawing.Point(762, 293);
            this.BrowserButton.Name = "BrowserButton";
            this.BrowserButton.Size = new System.Drawing.Size(170, 23);
            this.BrowserButton.TabIndex = 13;
            this.BrowserButton.Text = "Utilidades da Conta";
            this.BrowserButton.UseVisualStyleBackColor = true;
            this.BrowserButton.Click += new System.EventHandler(this.BrowserButton_Click);
            // 
            // DebugLogTextBox
            // 
            this.DebugLogTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DebugLogTextBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(30)))), ((int)(((byte)(30)))));
            this.DebugLogTextBox.Font = new System.Drawing.Font("Consolas", 7F);
            this.DebugLogTextBox.ForeColor = System.Drawing.Color.LightGreen;
            this.DebugLogTextBox.Location = new System.Drawing.Point(762, 322);
            this.DebugLogTextBox.Multiline = true;
            this.DebugLogTextBox.Name = "DebugLogTextBox";
            this.DebugLogTextBox.ReadOnly = true;
            this.DebugLogTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.DebugLogTextBox.Size = new System.Drawing.Size(170, 86);
            this.DebugLogTextBox.TabIndex = 1001;
            // 
            // AddFriendLabel
            // 
            this.AddFriendLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AddFriendLabel.AutoSize = true;
            this.AddFriendLabel.Location = new System.Drawing.Point(762, 415);
            this.AddFriendLabel.Name = "AddFriendLabel";
            this.AddFriendLabel.Size = new System.Drawing.Size(85, 13);
            this.AddFriendLabel.TabIndex = 1002;
            this.AddFriendLabel.Text = "adicionar amigo";
            // 
            // AddFriendTextBox
            // 
            this.AddFriendTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AddFriendTextBox.Location = new System.Drawing.Point(762, 431);
            this.AddFriendTextBox.Name = "AddFriendTextBox";
            this.AddFriendTextBox.Size = new System.Drawing.Size(125, 20);
            this.AddFriendTextBox.TabIndex = 1003;
            // 
            // AddFriendButton
            // 
            this.AddFriendButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AddFriendButton.Location = new System.Drawing.Point(893, 429);
            this.AddFriendButton.Name = "AddFriendButton";
            this.AddFriendButton.Size = new System.Drawing.Size(39, 23);
            this.AddFriendButton.TabIndex = 1004;
            this.AddFriendButton.Text = "add";
            this.AddFriendButton.UseVisualStyleBackColor = true;
            this.AddFriendButton.Click += new System.EventHandler(this.AddFriendButton_Click);
            // 
            // LabelPlaceID
            // 
            this.LabelPlaceID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LabelPlaceID.AutoSize = true;
            this.LabelPlaceID.Location = new System.Drawing.Point(760, 17);
            this.LabelPlaceID.Name = "LabelPlaceID";
            this.LabelPlaceID.Size = new System.Drawing.Size(59, 13);
            this.LabelPlaceID.TabIndex = 1000;
            this.LabelPlaceID.Text = "ID do Jogo";
            // 
            // PlaceTimer
            // 
            this.PlaceTimer.Interval = 400;
            this.PlaceTimer.Tick += new System.EventHandler(this.PlaceTimer_Tick);
            // 
            // OpenBrowserStrip
            // 
            this.OpenBrowserStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.customURLToolStripMenuItem,
            this.URLJSToolStripMenuItem,
            this.joinGroupToolStripMenuItem});
            this.OpenBrowserStrip.Name = "OpenBrowserStrip";
            this.OpenBrowserStrip.Size = new System.Drawing.Size(161, 70);
            // 
            // customURLToolStripMenuItem
            // 
            this.customURLToolStripMenuItem.Name = "customURLToolStripMenuItem";
            this.customURLToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.customURLToolStripMenuItem.Text = "URL";
            this.customURLToolStripMenuItem.Click += new System.EventHandler(this.customURLToolStripMenuItem_Click);
            // 
            // URLJSToolStripMenuItem
            // 
            this.URLJSToolStripMenuItem.Name = "URLJSToolStripMenuItem";
            this.URLJSToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.URLJSToolStripMenuItem.Text = "URL + Javascript";
            this.URLJSToolStripMenuItem.Click += new System.EventHandler(this.URLJSToolStripMenuItem_Click);
            // 
            // joinGroupToolStripMenuItem
            // 
            this.joinGroupToolStripMenuItem.Name = "joinGroupToolStripMenuItem";
            this.joinGroupToolStripMenuItem.Size = new System.Drawing.Size(160, 22);
            this.joinGroupToolStripMenuItem.Text = "Join Group";
            this.joinGroupToolStripMenuItem.Click += new System.EventHandler(this.joinGroupToolStripMenuItem_Click);
            // 
            // SaveTooltip
            // 
            this.SaveTooltip.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            // 
            // DefaultEncryptionButton
            // 
            this.DefaultEncryptionButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.DefaultEncryptionButton.Cursor = System.Windows.Forms.Cursors.Help;
            this.DefaultEncryptionButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DefaultEncryptionButton.Location = new System.Drawing.Point(3, 59);
            this.DefaultEncryptionButton.Name = "DefaultEncryptionButton";
            this.DefaultEncryptionButton.Size = new System.Drawing.Size(474, 50);
            this.DefaultEncryptionButton.TabIndex = 3;
            this.DefaultEncryptionButton.Tag = "UseControlFont";
            this.DefaultEncryptionButton.Text = "Default Encryption";
            this.SaveTooltip.SetToolTip(this.DefaultEncryptionButton, "This encryption method doesn\'t allow sharing\r\nyour account data across multiple d" +
        "evices\r\nunless you manually decrypt the data");
            this.DefaultEncryptionButton.UseVisualStyleBackColor = true;
            this.DefaultEncryptionButton.Click += new System.EventHandler(this.DefaultEncryptionButton_Click);
            // 
            // PasswordEncryptionButton
            // 
            this.PasswordEncryptionButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PasswordEncryptionButton.Cursor = System.Windows.Forms.Cursors.Help;
            this.PasswordEncryptionButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordEncryptionButton.Location = new System.Drawing.Point(3, 115);
            this.PasswordEncryptionButton.Name = "PasswordEncryptionButton";
            this.PasswordEncryptionButton.Size = new System.Drawing.Size(474, 51);
            this.PasswordEncryptionButton.TabIndex = 5;
            this.PasswordEncryptionButton.Tag = "UseControlFont";
            this.PasswordEncryptionButton.Text = "Password Locked (Recommended)";
            this.SaveTooltip.SetToolTip(this.PasswordEncryptionButton, "This encryption method allows sharing\r\nyour account data across multiple devices\r" +
        "\nand is recommended in order to prevent loss\r\nof data which can also be easily s" +
        "tored securely");
            this.PasswordEncryptionButton.UseVisualStyleBackColor = true;
            this.PasswordEncryptionButton.Click += new System.EventHandler(this.PasswordEncryptionButton_Click);
            // 
            // JobID
            // 
            this.JobID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.JobID.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(122)))), ((int)(((byte)(122)))));
            this.JobID.Location = new System.Drawing.Point(762, 78);
            this.JobID.Name = "JobID";
            this.JobID.Size = new System.Drawing.Size(145, 20);
            this.JobID.TabIndex = 2;
            this.SaveTooltip.SetToolTip(this.JobID, "Job ID is a unique ID assigned to every roblox server.\r\nYou may also put a Privat" +
        "e Server link in this box to join it.");
            this.JobID.Click += new System.EventHandler(this.JobID_Click);
            // 
            // ClearJobIDButton
            // 
            this.ClearJobIDButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ClearJobIDButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ClearJobIDButton.Location = new System.Drawing.Point(910, 77);
            this.ClearJobIDButton.Name = "ClearJobIDButton";
            this.ClearJobIDButton.Size = new System.Drawing.Size(25, 22);
            this.ClearJobIDButton.TabIndex = 3;
            this.ClearJobIDButton.Text = "✕";
            this.ClearJobIDButton.UseVisualStyleBackColor = true;
            this.ClearJobIDButton.Click += new System.EventHandler(this.ClearJobIDButton_Click);
            // 
            // AccountsView
            // 
            this.AccountsView.AllColumns.Add(this.Username);
            this.AccountsView.AllColumns.Add(this.Description);
            this.AccountsView.AllColumns.Add(this.Group);
            this.AccountsView.AllColumns.Add(this.LastUsedColumn);
            this.AccountsView.AllowDrop = true;
            this.AccountsView.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AccountsView.CellEditUseWholeCell = false;
            this.AccountsView.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Username,
            this.Description,
            this.Group});
            this.AccountsView.ContextMenuStrip = this.AccountsStrip;
            this.AccountsView.Cursor = System.Windows.Forms.Cursors.Default;
            this.AccountsView.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.75F);
            this.AccountsView.FullRowSelect = true;
            this.AccountsView.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.Nonclickable;
            this.AccountsView.HideSelection = false;
            this.AccountsView.IsSimpleDragSource = true;
            this.AccountsView.IsSimpleDropSink = true;
            this.AccountsView.Location = new System.Drawing.Point(280, 45);
            this.AccountsView.Name = "AccountsView";
            this.AccountsView.ShowSortIndicators = false;
            this.AccountsView.Size = new System.Drawing.Size(473, 389);
            this.AccountsView.SortGroupItemsByPrimaryColumn = false;
            this.AccountsView.TabIndex = 20;
            this.AccountsView.UseCompatibleStateImageBehavior = false;
            this.AccountsView.View = System.Windows.Forms.View.Details;
            this.AccountsView.ModelCanDrop += new System.EventHandler<BrightIdeasSoftware.ModelDropEventArgs>(this.AccountsView_ModelCanDrop);
            this.AccountsView.ModelDropped += new System.EventHandler<BrightIdeasSoftware.ModelDropEventArgs>(this.AccountsView_ModelDropped);
            this.AccountsView.Scroll += new System.EventHandler<System.Windows.Forms.ScrollEventArgs>(this.AccountsView_Scroll);
            this.AccountsView.SelectedIndexChanged += new System.EventHandler(this.AccountsView_SelectedIndexChanged);
            // 
            // Username
            // 
            this.Username.AspectName = "Username";
            this.Username.IsEditable = false;
            this.Username.Sortable = false;
            this.Username.Text = "Username";
            this.Username.Width = 252;
            // 
            // Description
            // 
            this.Description.AspectName = "Description";
            this.Description.Text = "Description";
            this.Description.Width = 200;
            // 
            // Group
            // 
            this.Group.AspectName = "Group";
            this.Group.Text = "";
            this.Group.Width = 0;
            // 
            // LastUsedColumn
            // 
            this.LastUsedColumn.AspectName = "LastUse";
            this.LastUsedColumn.AspectToStringFormat = "{0:MM/dd/yyyy hh:mm tt}";
            this.LastUsedColumn.DisplayIndex = 4;
            this.LastUsedColumn.IsVisible = false;
            this.LastUsedColumn.Text = "Last Used";
            this.LastUsedColumn.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.LastUsedColumn.Width = 130;
            // 
            // EditTheme
            // 
            this.EditTheme.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.EditTheme.Location = new System.Drawing.Point(762, 266);
            this.EditTheme.Name = "EditTheme";
            this.EditTheme.Size = new System.Drawing.Size(170, 23);
            this.EditTheme.TabIndex = 13;
            this.EditTheme.Text = "Editar Tema";
            this.EditTheme.UseVisualStyleBackColor = true;
            this.EditTheme.Click += new System.EventHandler(this.EditTheme_Click);
            // 
            // ConfigButton
            // 
            this.ConfigButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ConfigButton.FlatAppearance.BorderSize = 0;
            this.ConfigButton.Image = global::RBX_Alt_Manager.Properties.Resources.configIcon;
            this.ConfigButton.ImageAlign = System.Drawing.ContentAlignment.BottomRight;
            this.ConfigButton.Location = new System.Drawing.Point(910, 4);
            this.ConfigButton.Name = "ConfigButton";
            this.ConfigButton.Size = new System.Drawing.Size(24, 24);
            this.ConfigButton.TabIndex = 1002;
            this.ConfigButton.UseVisualStyleBackColor = true;
            this.ConfigButton.Click += new System.EventHandler(this.ConfigButton_Click);
            // 
            // HistoryIcon
            // 
            this.HistoryIcon.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.HistoryIcon.BackColor = System.Drawing.Color.Transparent;
            this.HistoryIcon.Image = global::RBX_Alt_Manager.Properties.Resources.icons8_history_32;
            this.HistoryIcon.Location = new System.Drawing.Point(244, 0);
            this.HistoryIcon.Name = "HistoryIcon";
            this.HistoryIcon.Size = new System.Drawing.Size(16, 16);
            this.HistoryIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.HistoryIcon.TabIndex = 1003;
            this.HistoryIcon.TabStop = false;
            this.HistoryIcon.Click += new System.EventHandler(this.HistoryIcon_Click);
            this.HistoryIcon.MouseHover += new System.EventHandler(this.HistoryIcon_MouseHover);
            // 
            // PasswordPanel
            // 
            this.PasswordPanel.Controls.Add(this.PasswordLayoutPanel);
            this.PasswordPanel.Controls.Add(this.PasswordSelectionPanel);
            this.PasswordPanel.Controls.Add(this.EncryptionSelectionPanel);
            this.PasswordPanel.Location = new System.Drawing.Point(1200, 0);
            this.PasswordPanel.Name = "PasswordPanel";
            this.PasswordPanel.Size = new System.Drawing.Size(784, 301);
            this.PasswordPanel.TabIndex = 1005;
            this.PasswordPanel.Visible = false;
            this.PasswordPanel.VisibleChanged += new System.EventHandler(this.PasswordPanel_VisibleChanged);
            // 
            // PasswordLayoutPanel
            // 
            this.PasswordLayoutPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PasswordLayoutPanel.ColumnCount = 1;
            this.PasswordLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.PasswordLayoutPanel.Controls.Add(this.UnlockButton, 0, 3);
            this.PasswordLayoutPanel.Controls.Add(this.PasswordTextBox, 0, 2);
            this.PasswordLayoutPanel.Controls.Add(this.AccessLabel, 0, 0);
            this.PasswordLayoutPanel.Controls.Add(this.PasswordRequiredLabel, 0, 1);
            this.PasswordLayoutPanel.Location = new System.Drawing.Point(192, 85);
            this.PasswordLayoutPanel.Name = "PasswordLayoutPanel";
            this.PasswordLayoutPanel.RowCount = 4;
            this.PasswordLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.PasswordLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.PasswordLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.PasswordLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.PasswordLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.PasswordLayoutPanel.Size = new System.Drawing.Size(400, 130);
            this.PasswordLayoutPanel.TabIndex = 5;
            // 
            // UnlockButton
            // 
            this.UnlockButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.UnlockButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UnlockButton.Location = new System.Drawing.Point(3, 92);
            this.UnlockButton.Name = "UnlockButton";
            this.UnlockButton.Size = new System.Drawing.Size(394, 35);
            this.UnlockButton.TabIndex = 3;
            this.UnlockButton.Tag = "UseControlFont";
            this.UnlockButton.Text = "Continue";
            this.UnlockButton.UseVisualStyleBackColor = true;
            this.UnlockButton.Click += new System.EventHandler(this.UnlockButton_Click);
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PasswordTextBox.Location = new System.Drawing.Point(3, 67);
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.PasswordChar = '*';
            this.PasswordTextBox.Size = new System.Drawing.Size(394, 20);
            this.PasswordTextBox.TabIndex = 2;
            this.PasswordTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PasswordTextBox_KeyPress);
            // 
            // AccessLabel
            // 
            this.AccessLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.AccessLabel.AutoSize = true;
            this.AccessLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AccessLabel.Location = new System.Drawing.Point(3, 0);
            this.AccessLabel.Name = "AccessLabel";
            this.AccessLabel.Size = new System.Drawing.Size(394, 25);
            this.AccessLabel.TabIndex = 1;
            this.AccessLabel.Tag = "UseControlFont";
            this.AccessLabel.Text = "Restricted Access";
            this.AccessLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PasswordRequiredLabel
            // 
            this.PasswordRequiredLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PasswordRequiredLabel.AutoSize = true;
            this.PasswordRequiredLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.PasswordRequiredLabel.Location = new System.Drawing.Point(3, 25);
            this.PasswordRequiredLabel.Name = "PasswordRequiredLabel";
            this.PasswordRequiredLabel.Size = new System.Drawing.Size(394, 39);
            this.PasswordRequiredLabel.TabIndex = 0;
            this.PasswordRequiredLabel.Tag = "UseControlFont";
            this.PasswordRequiredLabel.Text = "Please enter your password to continue";
            this.PasswordRequiredLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PasswordSelectionPanel
            // 
            this.PasswordSelectionPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PasswordSelectionPanel.ColumnCount = 1;
            this.PasswordSelectionPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.PasswordSelectionPanel.Controls.Add(this.SetPasswordButton, 0, 2);
            this.PasswordSelectionPanel.Controls.Add(this.PasswordSelectionTB, 0, 1);
            this.PasswordSelectionPanel.Controls.Add(this.Password2Label, 0, 0);
            this.PasswordSelectionPanel.Location = new System.Drawing.Point(242, 80);
            this.PasswordSelectionPanel.Name = "PasswordSelectionPanel";
            this.PasswordSelectionPanel.RowCount = 3;
            this.PasswordSelectionPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.PasswordSelectionPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.PasswordSelectionPanel.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.PasswordSelectionPanel.Size = new System.Drawing.Size(300, 88);
            this.PasswordSelectionPanel.TabIndex = 6;
            // 
            // SetPasswordButton
            // 
            this.SetPasswordButton.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SetPasswordButton.Enabled = false;
            this.SetPasswordButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SetPasswordButton.Location = new System.Drawing.Point(3, 51);
            this.SetPasswordButton.Name = "SetPasswordButton";
            this.SetPasswordButton.Size = new System.Drawing.Size(294, 34);
            this.SetPasswordButton.TabIndex = 3;
            this.SetPasswordButton.Tag = "UseControlFont";
            this.SetPasswordButton.Text = "Continue";
            this.SetPasswordButton.UseVisualStyleBackColor = true;
            this.SetPasswordButton.Click += new System.EventHandler(this.SetPasswordButton_Click);
            // 
            // PasswordSelectionTB
            // 
            this.PasswordSelectionTB.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PasswordSelectionTB.Location = new System.Drawing.Point(3, 25);
            this.PasswordSelectionTB.Name = "PasswordSelectionTB";
            this.PasswordSelectionTB.PasswordChar = '*';
            this.PasswordSelectionTB.ShortcutsEnabled = false;
            this.PasswordSelectionTB.Size = new System.Drawing.Size(294, 20);
            this.PasswordSelectionTB.TabIndex = 2;
            this.PasswordSelectionTB.TextChanged += new System.EventHandler(this.PasswordSelectionTB_TextChanged);
            // 
            // Password2Label
            // 
            this.Password2Label.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Password2Label.AutoSize = true;
            this.Password2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.Password2Label.Location = new System.Drawing.Point(3, 0);
            this.Password2Label.Name = "Password2Label";
            this.Password2Label.Size = new System.Drawing.Size(294, 22);
            this.Password2Label.TabIndex = 0;
            this.Password2Label.Tag = "UseControlFont";
            this.Password2Label.Text = "Password";
            this.Password2Label.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // EncryptionSelectionPanel
            // 
            this.EncryptionSelectionPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.EncryptionSelectionPanel.ColumnCount = 1;
            this.EncryptionSelectionPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.EncryptionSelectionPanel.Controls.Add(this.PasswordEncryptionButton, 0, 2);
            this.EncryptionSelectionPanel.Controls.Add(this.EncSelectionLabel, 0, 0);
            this.EncryptionSelectionPanel.Controls.Add(this.DefaultEncryptionButton, 0, 1);
            this.EncryptionSelectionPanel.Location = new System.Drawing.Point(152, 65);
            this.EncryptionSelectionPanel.Name = "EncryptionSelectionPanel";
            this.EncryptionSelectionPanel.RowCount = 3;
            this.EncryptionSelectionPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.EncryptionSelectionPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.EncryptionSelectionPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.EncryptionSelectionPanel.Size = new System.Drawing.Size(480, 169);
            this.EncryptionSelectionPanel.TabIndex = 6;
            this.EncryptionSelectionPanel.Visible = false;
            // 
            // EncSelectionLabel
            // 
            this.EncSelectionLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.EncSelectionLabel.AutoSize = true;
            this.EncSelectionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F);
            this.EncSelectionLabel.Location = new System.Drawing.Point(3, 0);
            this.EncSelectionLabel.Name = "EncSelectionLabel";
            this.EncSelectionLabel.Size = new System.Drawing.Size(474, 56);
            this.EncSelectionLabel.TabIndex = 4;
            this.EncSelectionLabel.Tag = "UseControlFont";
            this.EncSelectionLabel.Text = "Please select how you want your data to be secured";
            this.EncSelectionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // DownloadProgressBar
            // 
            this.DownloadProgressBar.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.DownloadProgressBar.BackColor = System.Drawing.SystemColors.MenuText;
            this.DownloadProgressBar.Cursor = System.Windows.Forms.Cursors.Help;
            this.DownloadProgressBar.Location = new System.Drawing.Point(13, 451);
            this.DownloadProgressBar.Name = "DownloadProgressBar";
            this.DownloadProgressBar.Size = new System.Drawing.Size(196, 11);
            this.DownloadProgressBar.Style = System.Windows.Forms.ProgressBarStyle.Continuous;
            this.DownloadProgressBar.TabIndex = 7;
            this.DownloadProgressBar.Visible = false;
            this.DownloadProgressBar.Click += new System.EventHandler(this.DownloadProgressBar_Click);
            // 
            // PresenceUpdateTimer
            // 
            this.PresenceUpdateTimer.Interval = 60000;
            // 
            // DLChromiumLabel
            // 
            this.DLChromiumLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.DLChromiumLabel.AutoSize = true;
            this.DLChromiumLabel.Cursor = System.Windows.Forms.Cursors.Help;
            this.DLChromiumLabel.Location = new System.Drawing.Point(781, 450);
            this.DLChromiumLabel.Name = "DLChromiumLabel";
            this.DLChromiumLabel.Size = new System.Drawing.Size(127, 13);
            this.DLChromiumLabel.TabIndex = 1006;
            this.DLChromiumLabel.Text = "Downloading Chromium...";
            this.DLChromiumLabel.Visible = false;
            this.DLChromiumLabel.Click += new System.EventHandler(this.DLChromiumLabel_Click);
            // 
            // SearchAccountsTextBox
            // 
            this.SearchAccountsTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.SearchAccountsTextBox.Location = new System.Drawing.Point(280, 19);
            this.SearchAccountsTextBox.Name = "SearchAccountsTextBox";
            this.SearchAccountsTextBox.Size = new System.Drawing.Size(445, 20);
            this.SearchAccountsTextBox.TabIndex = 1101;
            this.SearchAccountsTextBox.TextChanged += new System.EventHandler(this.SearchAccountsTextBox_TextChanged);
            // 
            // ClearSearchButton
            // 
            this.ClearSearchButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ClearSearchButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ClearSearchButton.Location = new System.Drawing.Point(728, 18);
            this.ClearSearchButton.Name = "ClearSearchButton";
            this.ClearSearchButton.Size = new System.Drawing.Size(25, 22);
            this.ClearSearchButton.TabIndex = 1102;
            this.ClearSearchButton.Text = "✕";
            this.ClearSearchButton.UseVisualStyleBackColor = true;
            this.ClearSearchButton.Click += new System.EventHandler(this.ClearSearchButton_Click);
            // 
            // SearchAccountsLabel
            // 
            this.SearchAccountsLabel.AutoSize = true;
            this.SearchAccountsLabel.Location = new System.Drawing.Point(277, 4);
            this.SearchAccountsLabel.Name = "SearchAccountsLabel";
            this.SearchAccountsLabel.Size = new System.Drawing.Size(50, 13);
            this.SearchAccountsLabel.TabIndex = 1100;
            this.SearchAccountsLabel.Text = "Procurar:";
            // 
            // PrivateServersPanel
            // 
            this.PrivateServersPanel.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.PrivateServersPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.PrivateServersPanel.Controls.Add(this.AddServerButton);
            this.PrivateServersPanel.Controls.Add(this.NewServerLinkTextBox);
            this.PrivateServersPanel.Controls.Add(this.NewServerLinkLabel);
            this.PrivateServersPanel.Controls.Add(this.NewServerNameTextBox);
            this.PrivateServersPanel.Controls.Add(this.NewServerNameLabel);
            this.PrivateServersPanel.Controls.Add(this.PrivateServersListPanel);
            this.PrivateServersPanel.Controls.Add(this.PrivateServersLabel);
            this.PrivateServersPanel.Controls.Add(this.HistoryIcon);
            this.PrivateServersPanel.Location = new System.Drawing.Point(8, 13);
            this.PrivateServersPanel.Name = "PrivateServersPanel";
            this.PrivateServersPanel.Size = new System.Drawing.Size(263, 453);
            this.PrivateServersPanel.TabIndex = 1200;
            // 
            // AddServerButton
            // 
            this.AddServerButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.AddServerButton.Location = new System.Drawing.Point(214, 425);
            this.AddServerButton.Name = "AddServerButton";
            this.AddServerButton.Size = new System.Drawing.Size(44, 23);
            this.AddServerButton.TabIndex = 6;
            this.AddServerButton.Text = "Add";
            this.AddServerButton.UseVisualStyleBackColor = true;
            this.AddServerButton.Click += new System.EventHandler(this.AddServerButton_Click);
            // 
            // NewServerLinkTextBox
            // 
            this.NewServerLinkTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.NewServerLinkTextBox.Location = new System.Drawing.Point(3, 427);
            this.NewServerLinkTextBox.Name = "NewServerLinkTextBox";
            this.NewServerLinkTextBox.Size = new System.Drawing.Size(208, 20);
            this.NewServerLinkTextBox.TabIndex = 5;
            // 
            // NewServerLinkLabel
            // 
            this.NewServerLinkLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.NewServerLinkLabel.AutoSize = true;
            this.NewServerLinkLabel.Location = new System.Drawing.Point(3, 411);
            this.NewServerLinkLabel.Name = "NewServerLinkLabel";
            this.NewServerLinkLabel.Size = new System.Drawing.Size(30, 13);
            this.NewServerLinkLabel.TabIndex = 4;
            this.NewServerLinkLabel.Text = "Link:";
            // 
            // NewServerNameTextBox
            // 
            this.NewServerNameTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.NewServerNameTextBox.Location = new System.Drawing.Point(3, 388);
            this.NewServerNameTextBox.Name = "NewServerNameTextBox";
            this.NewServerNameTextBox.Size = new System.Drawing.Size(255, 20);
            this.NewServerNameTextBox.TabIndex = 3;
            // 
            // NewServerNameLabel
            // 
            this.NewServerNameLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.NewServerNameLabel.AutoSize = true;
            this.NewServerNameLabel.Location = new System.Drawing.Point(3, 372);
            this.NewServerNameLabel.Name = "NewServerNameLabel";
            this.NewServerNameLabel.Size = new System.Drawing.Size(95, 13);
            this.NewServerNameLabel.TabIndex = 2;
            this.NewServerNameLabel.Text = "Nome do Servidor:";
            // 
            // PrivateServersListPanel
            // 
            this.PrivateServersListPanel.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PrivateServersListPanel.AutoScroll = true;
            this.PrivateServersListPanel.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
            this.PrivateServersListPanel.Location = new System.Drawing.Point(3, 20);
            this.PrivateServersListPanel.Name = "PrivateServersListPanel";
            this.PrivateServersListPanel.Size = new System.Drawing.Size(255, 347);
            this.PrivateServersListPanel.TabIndex = 1;
            this.PrivateServersListPanel.WrapContents = false;
            // 
            // PrivateServersLabel
            // 
            this.PrivateServersLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold);
            this.PrivateServersLabel.Location = new System.Drawing.Point(3, 3);
            this.PrivateServersLabel.Name = "PrivateServersLabel";
            this.PrivateServersLabel.Size = new System.Drawing.Size(172, 15);
            this.PrivateServersLabel.TabIndex = 0;
            this.PrivateServersLabel.Text = "Servidores Privados";
            // 
            // AntiCaptchaComboBox
            // 
            this.AntiCaptchaComboBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AntiCaptchaComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AntiCaptchaComboBox.FormattingEnabled = true;
            this.AntiCaptchaComboBox.Location = new System.Drawing.Point(842, 414);
            this.AntiCaptchaComboBox.Name = "AntiCaptchaComboBox";
            this.AntiCaptchaComboBox.Size = new System.Drawing.Size(90, 21);
            this.AntiCaptchaComboBox.TabIndex = 1301;
            this.AntiCaptchaComboBox.SelectedIndexChanged += new System.EventHandler(this.AntiCaptchaComboBox_SelectedIndexChanged);
            // 
            // AntiCaptchaLabel
            // 
            this.AntiCaptchaLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.AntiCaptchaLabel.AutoSize = true;
            this.AntiCaptchaLabel.Location = new System.Drawing.Point(764, 418);
            this.AntiCaptchaLabel.Name = "AntiCaptchaLabel";
            this.AntiCaptchaLabel.Size = new System.Drawing.Size(71, 13);
            this.AntiCaptchaLabel.TabIndex = 1300;
            this.AntiCaptchaLabel.Text = "Anti-Captcha:";
            // 
            // AddUserPassButton
            // 
            this.AddUserPassButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.AddUserPassButton.Location = new System.Drawing.Point(280, 440);
            this.AddUserPassButton.Name = "AddUserPassButton";
            this.AddUserPassButton.Size = new System.Drawing.Size(75, 23);
            this.AddUserPassButton.TabIndex = 14;
            this.AddUserPassButton.Text = "User:Pass";
            this.AddUserPassButton.UseVisualStyleBackColor = true;
            this.AddUserPassButton.Click += new System.EventHandler(this.AddUserPassButton_Click);
            // 
            // AddCookieButton
            // 
            this.AddCookieButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.AddCookieButton.Location = new System.Drawing.Point(360, 440);
            this.AddCookieButton.Name = "AddCookieButton";
            this.AddCookieButton.Size = new System.Drawing.Size(60, 23);
            this.AddCookieButton.TabIndex = 15;
            this.AddCookieButton.Text = "Cookie";
            this.AddCookieButton.UseVisualStyleBackColor = true;
            this.AddCookieButton.Click += new System.EventHandler(this.AddCookieButton_Click);
            // 
            // OpenBrowser
            // 
            this.OpenBrowser.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.OpenBrowser.Location = new System.Drawing.Point(426, 440);
            this.OpenBrowser.Menu = this.OpenBrowserStrip;
            this.OpenBrowser.Name = "OpenBrowser";
            this.OpenBrowser.Size = new System.Drawing.Size(143, 23);
            this.OpenBrowser.TabIndex = 18;
            this.OpenBrowser.Text = "Abrir Navegador";
            this.OpenBrowser.UseVisualStyleBackColor = true;
            this.OpenBrowser.Click += new System.EventHandler(this.OpenBrowser_Click);
            // 
            // UserID
            // 
            this.UserID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.UserID.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(122)))), ((int)(((byte)(122)))));
            this.UserID.Location = new System.Drawing.Point(762, 172);
            this.UserID.Name = "UserID";
            this.UserID.Size = new System.Drawing.Size(101, 20);
            this.UserID.TabIndex = 7;
            // 
            // DescriptionBox
            // 
            this.DescriptionBox.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.DescriptionBox.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(122)))), ((int)(((byte)(122)))));
            this.DescriptionBox.Location = new System.Drawing.Point(762, 201);
            this.DescriptionBox.Name = "DescriptionBox";
            this.DescriptionBox.Size = new System.Drawing.Size(170, 34);
            this.DescriptionBox.TabIndex = 11;
            this.DescriptionBox.Text = "Description";
            // 
            // PlaceID
            // 
            this.PlaceID.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.PlaceID.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(122)))), ((int)(((byte)(122)))), ((int)(((byte)(122)))));
            this.PlaceID.Location = new System.Drawing.Point(762, 34);
            this.PlaceID.Name = "PlaceID";
            this.PlaceID.Size = new System.Drawing.Size(172, 20);
            this.PlaceID.TabIndex = 1;
            this.PlaceID.Text = "5315046213";
            this.PlaceID.Click += new System.EventHandler(this.PlaceID_Click);
            this.PlaceID.TextChanged += new System.EventHandler(this.PlaceID_TextChanged);
            // 
            // AccountManager
            // 
            this.AllowDrop = true;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(946, 470);
            this.Controls.Add(this.Remover);
            this.Controls.Add(this.AddUserPassButton);
            this.Controls.Add(this.AddCookieButton);
            this.Controls.Add(this.AntiCaptchaLabel);
            this.Controls.Add(this.AntiCaptchaComboBox);
            this.Controls.Add(this.DLChromiumLabel);
            this.Controls.Add(this.ConfigButton);
            this.Controls.Add(this.EditTheme);
            this.Controls.Add(this.OpenBrowser);
            this.Controls.Add(this.BrowserButton);
            this.Controls.Add(this.DebugLogTextBox);
            this.Controls.Add(this.AddFriendLabel);
            this.Controls.Add(this.AddFriendTextBox);
            this.Controls.Add(this.AddFriendButton);
            this.Controls.Add(this.LabelUserID);
            this.Controls.Add(this.UserID);
            this.Controls.Add(this.Follow);
            this.Controls.Add(this.DescriptionBox);
            this.Controls.Add(this.SetDescription);
            this.Controls.Add(this.SolveCaptchaButton);
            this.Controls.Add(this.JoinServer);
            this.Controls.Add(this.LabelJobID);
            this.Controls.Add(this.LabelPlaceID);
            this.Controls.Add(this.JobID);
            this.Controls.Add(this.ClearJobIDButton);
            this.Controls.Add(this.PlaceID);
            this.Controls.Add(this.SearchAccountsTextBox);
            this.Controls.Add(this.ClearSearchButton);
            this.Controls.Add(this.SearchAccountsLabel);
            this.Controls.Add(this.PrivateServersPanel);
            this.Controls.Add(this.AccountsView);
            this.Controls.Add(this.PasswordPanel);
            this.Controls.Add(this.DownloadProgressBar);
            this.HelpButton = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(900, 340);
            this.Name = "AccountManager";
            this.Text = "Blox Brasil Gerenciador de Contas";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.AccountManager_FormClosing);
            this.Load += new System.EventHandler(this.AccountManager_Load);
            this.Shown += new System.EventHandler(this.AccountManager_Shown);
            this.AddAccountsStrip.ResumeLayout(false);
            this.AccountsStrip.ResumeLayout(false);
            this.OpenBrowserStrip.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.AccountsView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HistoryIcon)).EndInit();
            this.PasswordPanel.ResumeLayout(false);
            this.PasswordLayoutPanel.ResumeLayout(false);
            this.PasswordLayoutPanel.PerformLayout();
            this.PasswordSelectionPanel.ResumeLayout(false);
            this.PasswordSelectionPanel.PerformLayout();
            this.EncryptionSelectionPanel.ResumeLayout(false);
            this.EncryptionSelectionPanel.PerformLayout();
            this.PrivateServersPanel.ResumeLayout(false);
            this.PrivateServersPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        public Classes.BorderedTextBox PlaceID;
        public Classes.BorderedTextBox JobID;
        private System.Windows.Forms.Button ClearJobIDButton;
        private System.Windows.Forms.Label LabelJobID;
        private System.Windows.Forms.Button AddUserPassButton;
        private System.Windows.Forms.Button AddCookieButton;
        private System.Windows.Forms.Button Remover;
        private System.Windows.Forms.Button JoinServer;
        private System.Windows.Forms.Button SetDescription;
        private Classes.BorderedRichTextBox DescriptionBox;
        private System.Windows.Forms.Button Follow;
        private Classes.BorderedTextBox UserID;
        private System.Windows.Forms.Label LabelUserID;
        private System.Windows.Forms.ContextMenuStrip AccountsStrip;
        private System.Windows.Forms.ToolStripMenuItem addAccountsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem removeAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem infoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem getAuthenticationTicketToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyRbxplayerLinkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyUsernameToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copySecurityTokenToolStripMenuItem;
        private System.Windows.Forms.Button BrowserButton;
        private System.Windows.Forms.TextBox DebugLogTextBox;
        private System.Windows.Forms.Label AddFriendLabel;
        private System.Windows.Forms.TextBox AddFriendTextBox;
        private System.Windows.Forms.Button AddFriendButton;
        private System.Windows.Forms.Label LabelPlaceID;
        private System.Windows.Forms.Timer PlaceTimer;
        private System.Windows.Forms.ToolStripMenuItem moveGroupUpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem moveToToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyAppLinkToolStripMenuItem;
        private MenuButton OpenBrowser;
        private System.Windows.Forms.ToolStripMenuItem copyProfileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewFieldsToolStripMenuItem;
        private System.Windows.Forms.ToolTip SaveTooltip;
        public BrightIdeasSoftware.ObjectListView AccountsView;
        private BrightIdeasSoftware.OLVColumn Group;
        private BrightIdeasSoftware.OLVColumn Username;
        private BrightIdeasSoftware.OLVColumn Description;
        private System.Windows.Forms.ToolStripMenuItem sortAlphabeticallyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toggleToolStripMenuItem;
        private System.Windows.Forms.Button EditTheme;
        private System.Windows.Forms.ToolStripMenuItem groupsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem infoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem copyPasswordToolStripMenuItem;
        private System.Windows.Forms.Button ConfigButton;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyUserIdToolStripMenuItem;
        private System.Windows.Forms.PictureBox HistoryIcon;
        private BrightIdeasSoftware.OLVColumn LastUsedColumn;
        private System.Windows.Forms.ToolStripMenuItem copyGroupToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyUserPassComboToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ShowDetailsToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip AddAccountsStrip;
        private System.Windows.Forms.ToolStripMenuItem manualToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bulkUserPassToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem byCookieToolStripMenuItem;
        private System.Windows.Forms.ContextMenuStrip OpenBrowserStrip;
        private System.Windows.Forms.ToolStripMenuItem customURLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem URLJSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem joinGroupToolStripMenuItem;
        private System.Windows.Forms.Panel PasswordPanel;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.Label AccessLabel;
        private System.Windows.Forms.Button UnlockButton;
        private System.Windows.Forms.TableLayoutPanel PasswordLayoutPanel;
        private System.Windows.Forms.Label PasswordRequiredLabel;
        private System.Windows.Forms.TableLayoutPanel EncryptionSelectionPanel;
        private System.Windows.Forms.Label EncSelectionLabel;
        private System.Windows.Forms.Button DefaultEncryptionButton;
        private System.Windows.Forms.Button PasswordEncryptionButton;
        private System.Windows.Forms.TableLayoutPanel PasswordSelectionPanel;
        private System.Windows.Forms.Button SetPasswordButton;
        private System.Windows.Forms.TextBox PasswordSelectionTB;
        private System.Windows.Forms.Label Password2Label;
        private System.Windows.Forms.Timer PresenceUpdateTimer;
        private System.Windows.Forms.ToolStripMenuItem quickLogInToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem customURLJSToolStripMenuItem;
        private System.Windows.Forms.ProgressBar DownloadProgressBar;
        private System.Windows.Forms.Label DLChromiumLabel;
        private System.Windows.Forms.TextBox SearchAccountsTextBox;
        private System.Windows.Forms.Button ClearSearchButton;
        private System.Windows.Forms.Label SearchAccountsLabel;
        private System.Windows.Forms.Panel PrivateServersPanel;
        private System.Windows.Forms.Label PrivateServersLabel;
        private System.Windows.Forms.FlowLayoutPanel PrivateServersListPanel;
        private System.Windows.Forms.Button AddServerButton;
        private System.Windows.Forms.TextBox NewServerNameTextBox;
        private System.Windows.Forms.TextBox NewServerLinkTextBox;
        private System.Windows.Forms.Label NewServerNameLabel;
        private System.Windows.Forms.Label NewServerLinkLabel;
        private System.Windows.Forms.ComboBox AntiCaptchaComboBox;
        private System.Windows.Forms.Label AntiCaptchaLabel;
        private System.Windows.Forms.Button SolveCaptchaButton;
    }
}